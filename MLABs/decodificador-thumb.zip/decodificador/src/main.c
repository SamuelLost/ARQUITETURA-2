//Biblioteca com a função
#include "DECODER_THUMB.h"

int main(){
	instructionDecoder(opcode, instruction);
	return 0;
}
